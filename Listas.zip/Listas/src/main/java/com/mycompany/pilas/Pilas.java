
package com.mycompany.pilas;

import java.util.Scanner;
public class Pilas {

    public static void main(String[] args) {
           Scanner teclado = new Scanner(System.in);
          int[]pila = new int[5];
          
          int tope = -1;
          int opcion;
          
          do {
              System.out.println("Pila con arreglos");
              System.out.println("1 = Agregar un numero a la pila");
              System.out.println("2 = Eliminar un numero de la pila");
              System.out.println("3 = Mostrar la pila");
              System.out.println("4 = Mostar el tope");
              System.out.println("5 = Salir");
              System.out.println("6 = Opciones");
              opcion=teclado.nextInt();
              
              switch(opcion){
                  
                case 1:
                    
                if (tope==pila.length-1){
                    System.out.println("Esta pila esta llena");
                }else{
                    System.out.println("Agrega un elemento a la pila");
                    int numero = teclado.nextInt();
                    tope++;
                    pila[tope]=numero;
                }
                break;
                
                case 2:
                    
                if (tope== -1){
                    
                    System.out.println("Esta pila esta vacia");  
                }else{
                    System.out.println("Retirar" + pila[tope]);   
                }    
                   break; 
                case 3:
                    
                 if ( tope== -1){
                     System.out.println("La pila esta vacia");
                 }else{
                     System.out.println("Mostrar la pila de elementos");
                     
                   for (int i = tope; i>=0 ; i--){
                       System.out.println("Pila" + pila[i] );  
                   }  
                 }   
                   break;
                 
                case 4:
                    
                  if ( tope== -1){
                     System.out.println("La pila esta vacia");
                 }else{
                      System.out.println("Aqui esta una de las pilas" + pila[tope] );
                  }   
                   break; 
                case 5:  
                   
                    System.out.println("Fin del programa");   
                    
                 break;
                
               default:
               System.out.println("Opción invalida"); 
          }
    }while(opcion!=5);
 }
}   
